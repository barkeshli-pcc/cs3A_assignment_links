#include <iostream>
#include "animate.h"
using namespace std;

int main()
{

    //Vector v;
    animate game;
    game.run();
    cout<<endl<<endl<<"------ MAIN EXITING --------------------------"<<endl;
    return 0;
}
