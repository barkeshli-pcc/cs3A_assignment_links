#include <iostream>
#include "posint.h"

using namespace std;

int main()
{
    PosInt a(9);
    cout<<"a: "<<a<<endl;

    PosInt b(4);
    cout<<"b: ";
    cout<<b;
    cout<<endl;

    PosInt c;
    c = a + b;
    cout<<"a + b: ";
    cout<<c;
    cout<<endl;
    return 0;


    c = b.sub(a);
    if (c.Error()){
        cout<<"b - a: "<<endl;
        cout<<c.ErrorDescr(c.Error())<<endl;
        cout<<"Object is reset to default values"<<endl;
        c.Clear();
    }
    else
        cout<<"b - a: "<<c.Get()<<endl;
    c = a.sub(b);
    cout<<"a - b: "<<c.Get()<<endl;
    cout << "=============END===========" << endl;
    return 0;
}

